package Main;

import javax.swing.JOptionPane;

import Entidade.AlunoEntidade;

public class AlunoMain {
	public static void main(String[] args) {
		AlunoEntidade ae = new AlunoEntidade(0, "Joao", "Rua Pedro Paulo", "556",
				"casa 5", "19801023", "joao@mail.com", "11111111",
				"9655344255", "122113848", "09170825751");
		
		
		//Aluno-Incluir: Cria objeto AlunoEntidadeTO e manda para o DAO incluir no Banco
		ae.criar();
		
		//Aluno-Pesquisar: Realiza uma busca de aluno por CPF, o DAO instancia AlunoEntidadeTO, retorna para AlunoEntidade e faz o espelhamento 
		ae.carregar();
		
		//Impressao com resultado do carregamento do banco
		JOptionPane.showMessageDialog(null, "Nome = " + ae.getNome()
									+ "\nEndere�o = " + ae.getEnd()
									+ ", N� " + ae.getNum()
									+ "\nComplemento = " + ae.getComp()
									+ "\nData Nascimento = " + ae.getDataNasc()
									+ "\nEmail = " + ae.getEmail()
									+ "\nTel. Res.: = " + ae.getTelRes()
									+ "\nTel. Cel.: = " + ae.getTelCel()
									+ "\nRG = " + ae.getRg()
									+ "\nCpf = " + ae.getCpf());
		
		
		//Aluno-Alterar: Altera o telefone em AlunoEntidade
		ae.setTelRes("22222222");
		
		//Aluno-atualizar: Realiza um UPDATE no banco, alterando o numero telefonico
		ae.atualizar();
	
		JOptionPane.showMessageDialog(null, "Nome = " + ae.getNome()     
									+ "\nEndere�o = " + ae.getEnd()      
									+ ", N� " + ae.getNum()      
									+ "\nComplemento = " + ae.getComp()
									+ "\nData Nascimento = " + ae.getDataNasc()
									+ "\nEmail = " + ae.getEmail()
									+ "\nTel. Res.: = " + ae.getTelRes()
									+ "\nTel. Cel.: = " + ae.getTelCel()
									+ "\nRG = " + ae.getRg()
									+ "\nCpf = " + ae.getCpf());
		
		ae.carregar();

		JOptionPane.showMessageDialog(null, "Nome = " + ae.getNome()
									+ "\nEndere�o = " + ae.getEnd()
									+ ", N� " + ae.getNum()
									+ "\nComplemento = " + ae.getComp()
									+ "\nData Nascimento = " + ae.getDataNasc()
									+ "\nEmail = " + ae.getEmail()
									+ "\nTel. Res.: = " + ae.getTelRes()
									+ "\nTel. Cel.: = " + ae.getTelCel()
									+ "\nRG = " + ae.getRg()
									+ "\nCpf = " + ae.getCpf());
		
		//Aluno-exclui: Exclui o aluno do banco
		ae.excluir();
		JOptionPane.showMessageDialog(null, "excluido do banco");
		
		//Aluno-pesquisar
		ae.carregar();

		JOptionPane.showMessageDialog(null, "Nome = " + ae.getNome()
									+ "\nEndere�o = " + ae.getEnd()
									+ ", N� " + ae.getNum()
									+ "\nComplemento = " + ae.getComp()
									+ "\nData Nascimento = " + ae.getDataNasc()
									+ "\nEmail = " + ae.getEmail()
									+ "\nTel. Res.: = " + ae.getTelRes()
									+ "\nTel. Cel.: = " + ae.getTelCel()
									+ "\nRG = " + ae.getRg()
									+ "\nCpf = " + ae.getCpf());
	}
}
