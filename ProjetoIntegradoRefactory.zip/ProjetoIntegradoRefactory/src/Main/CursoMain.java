package Main;
import javax.swing.JOptionPane;

import Entidade.CursoEntidade;

public class CursoMain {

	public static void main(String[] args) {
		
		//Curso-cria objeto: Instancia do objeto CursoEntidade
		CursoEntidade ce = new CursoEntidade(1, "Informatica", "20160306",
				"20160405", "08:00", "15:00", 30, "apostilas", "Notebook", 300.00);
		
		//Curso-inluir: Cria objeto AlunoEntidadeTO e manda para o DAO incluir no Banco
		ce.criar();
		
		//Curso-pesquisar: Realiza uma busca de aluno por CPF, o DAO instancia AlunoEntidadeTO, retorna para AlunoEntidade e faz o espelhamento 
		ce.carregar(ce.getCodCurso());

		JOptionPane.showMessageDialog(null, "C�d. Curso = " + ce.getCodCurso()
											+ "\nCurso = " + ce.getCurso()
											+ "\nData In�cio = " + ce.getDataIni()
											+ "\nData Fim = " + ce.getDataFim()
											+ "\nHora In�cio = " + ce.getHoraIni()
											+ "\nHora Final = " + ce.getHoraFim()
											+ "\nVagas = " + ce.getQtdVagas()
											+ "\nLivros = " + ce.getLivros()
											+ "\nMateriais = " + ce.getMateriais()
											+ "\nValor = R$" + ce.getValor());   
		
		//Curso-alterar-material: Altera o tipo de material relacionado ao curso
		ce.setMateriais("Caderno");
		
		//Curso-atualizar: Realiza um UPDATE no banco, alterando o tipo de material
		ce.atualizar();
		
		JOptionPane.showMessageDialog(null, "C�d. Curso = " + ce.getCodCurso()
											+ "\nCurso = " + ce.getCurso()
											+ "\nData In�cio = " + ce.getDataIni()
											+ "\nData Fim = " + ce.getDataFim()
											+ "\nHora In�cio = " + ce.getHoraIni()
											+ "\nHora Final = " + ce.getHoraFim()
											+ "\nVagas = " + ce.getQtdVagas()
											+ "\nLivros = " + ce.getLivros()
											+ "\nMateriais = " + ce.getMateriais()
											+ "\nValor = R$" + ce.getValor());   
		
		ce.carregar(ce.getCodCurso());
		
		JOptionPane.showMessageDialog(null, "C�d. Curso = " + ce.getCodCurso()
											+ "\nCurso = " + ce.getCurso()
											+ "\nData In�cio = " + ce.getDataIni()
											+ "\nData Fim = " + ce.getDataFim()
											+ "\nHora In�cio = " + ce.getHoraIni()
											+ "\nHora Final = " + ce.getHoraFim()
											+ "\nVagas = " + ce.getQtdVagas()
											+ "\nLivros = " + ce.getLivros()
											+ "\nMateriais = " + ce.getMateriais()
											+ "\nValor = R$" + ce.getValor());   
		
		//Curso-excluir
		ce.excluir();
		JOptionPane.showMessageDialog(null, "excluido do banco");
		
		ce.carregar(ce.getCodCurso());
		
		JOptionPane.showMessageDialog(null, "C�d. Curso = " + ce.getCodCurso()
											+ "\nCurso = " + ce.getCurso()
											+ "\nData In�cio = " + ce.getDataIni()
											+ "\nData Fim = " + ce.getDataFim()
											+ "\nHora In�cio = " + ce.getHoraIni()
											+ "\nHora Final = " + ce.getHoraFim()
											+ "\nVagas = " + ce.getQtdVagas()
											+ "\nLivros = " + ce.getLivros()
											+ "\nMateriais = " + ce.getMateriais()
											+ "\nValor = R$" + ce.getValor());   
		
	}

}
