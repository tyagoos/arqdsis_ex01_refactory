SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema CursoPresencial
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `CursoPresencial` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
USE `CursoPresencial` ;

-- -----------------------------------------------------
-- Table `CursoPresencial`.`Aluno`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `CursoPresencial`.`Aluno` ;

CREATE TABLE IF NOT EXISTS `CursoPresencial`.`Aluno` (
  `nomeAlu` VARCHAR(45) NOT NULL,
  `endereco` VARCHAR(100) NOT NULL,
  `numero` VARCHAR(5) NOT NULL,
  `complemento` VARCHAR(15) NULL,
  `dataNasc` DATE NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  `telRes` VARCHAR(20) NULL,
  `telCel` VARCHAR(20) NULL,
  `rg` VARCHAR(15) NOT NULL,
  `cpf` VARCHAR(15) NOT NULL,
  PRIMARY KEY (`cpf`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `CursoPresencial`.`Curso`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `CursoPresencial`.`Curso` ;

CREATE TABLE IF NOT EXISTS `CursoPresencial`.`Curso` (
  `codigoCurso` INT NOT NULL,
  `curso` VARCHAR(30) NOT NULL,
  `dataIni` DATE NOT NULL,
  `dataFim` DATE NOT NULL,
  `horaIni` VARCHAR(10) NOT NULL,
  `horaFim` VARCHAR(10) NOT NULL,
  `qtdVagas` INT NOT NULL,
  `livros` VARCHAR(200) NOT NULL,
  `materiais` VARCHAR(200) NOT NULL,
  `valor` FLOAT NOT NULL,
  PRIMARY KEY (`codigoCurso`),
  UNIQUE INDEX `codigoCurso_UNIQUE` (`codigoCurso` ASC))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `CursoPresencial`.`Matricula`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `CursoPresencial`.`Matricula` ;

CREATE TABLE IF NOT EXISTS `CursoPresencial`.`Matricula` (
  `idMatricula` INT NOT NULL AUTO_INCREMENT,
  `dataMat` DATE NOT NULL,
  `valorMat` DECIMAL NOT NULL,
  `tipoPagamentoMat` VARCHAR(20) NOT NULL,
  `statusMat` TINYINT(1) NOT NULL,
  `dataCancel` DATE NOT NULL,
  `curso` VARCHAR(30) NOT NULL,
  `Curso_codigoCurso` INT NOT NULL,
  `Aluno_cpf` VARCHAR(15) NOT NULL,
  PRIMARY KEY (`idMatricula`),
  INDEX `fk_Matricula_Curso_idx` (`Curso_codigoCurso` ASC),
  INDEX `fk_Matricula_Aluno1_idx` (`Aluno_cpf` ASC),
  CONSTRAINT `fk_Matricula_Curso`
    FOREIGN KEY (`Curso_codigoCurso`)
    REFERENCES `CursoPresencial`.`Curso` (`codigoCurso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Matricula_Aluno1`
    FOREIGN KEY (`Aluno_cpf`)
    REFERENCES `CursoPresencial`.`Aluno` (`cpf`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
